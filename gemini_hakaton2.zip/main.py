import os
import re
import json
import math
import shutil
import tempfile
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple, Any

import cv2
import numpy as np
import gradio as gr
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, JSONResponse

import traceback
from google import genai
from google.genai import types
from pydantic import BaseModel, Field

import imageio_ffmpeg
# ffmpeg가 설치되어있지 않은 환경을 대비해 imageio_ffmpeg의 바이너리를 PATH에 추가합니다.
# 덕분에 로컬 시스템 환경변수 편집 없이도 FFmpeg 병합/편집 기능이 작동합니다.
os.environ["PATH"] += os.pathsep + os.path.dirname(imageio_ffmpeg.get_ffmpeg_exe())

# -----------------------------
# YouTube Downloader
# -----------------------------
def download_youtube_video(url: str, res: str = "720p", out_dir: str = ".") -> str:
    if not url.strip():
        return ""
    import yt_dlp
    
    # 해상도 설정
    if res == "1080p":
        format_str = "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/best[height<=1080][ext=mp4]/best"
    elif res == "720p":
        format_str = "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[height<=720][ext=mp4]/best"
    else:
        format_str = "best"

    out_tmpl = os.path.join(out_dir, "yt_downloaded_%(id)s.%(ext)s")
    
    ydl_opts = {
        'format': format_str,
        'outtmpl': out_tmpl,
        'merge_output_format': 'mp4',
        'ffmpeg_location': imageio_ffmpeg.get_ffmpeg_exe(),
        'quiet': False
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info_dict = ydl.extract_info(url, download=True)
        filename = ydl.prepare_filename(info_dict)
        # yt-dlp가 mkv 등으로 병합한 뒤 mp4로 변환할 경우를 대비하여 확장자 확인
        if not os.path.exists(filename):
            base, _ = os.path.splitext(filename)
            if os.path.exists(base + '.mp4'):
                filename = base + '.mp4'
            elif os.path.exists(base + '.mkv'):
                filename = base + '.mkv'
            elif os.path.exists(base + '.webm'):
                filename = base + '.webm'
        return filename

# -----------------------------
# MoviePy for Cut Editing
# -----------------------------
try:
    from moviepy.editor import VideoFileClip, concatenate_videoclips
    HAS_MOVIEPY = True
except ImportError:
    HAS_MOVIEPY = False

# -----------------------------
# Models (Structured Output)
# -----------------------------
class TrackFrame(BaseModel):
    t: float = Field(description="Time in seconds for this frame.")
    box_2d: Optional[List[int]] = Field(
        default=None,
        description="Normalized bounding box [ymin,xmin,ymax,xmax] in integers 0..1000, or null.",
    )


class TrackResponse(BaseModel):
    frames: List[TrackFrame]


# -----------------------------
# Utility helpers
# -----------------------------
def _require_env():
    pass  # API Key is now hardcoded


def _run(cmd: List[str]) -> None:
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"Command failed:\n{' '.join(cmd)}\n\nSTDERR:\n{p.stderr}")


def get_ffmpeg_path() -> str:
    return imageio_ffmpeg.get_ffmpeg_exe()

def _ffmpeg_exists() -> bool:
    return os.path.exists(get_ffmpeg_path())


def clip_video(input_path: str, start_s: float, end_s: float, out_path: str) -> str:
    if not _ffmpeg_exists():
        raise RuntimeError(f"ffmpeg not found at {get_ffmpeg_path()}")
    if end_s <= start_s:
        raise ValueError("end_s must be > start_s")

    cmd = [
        get_ffmpeg_path(), "-y",
        "-ss", str(start_s),
        "-to", str(end_s),
        "-i", input_path,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
        "-c:a", "aac", "-b:a", "128k",
        out_path
    ]
    _run(cmd)
    return out_path


def extract_frames(input_path: str, fps: float, out_dir: str) -> List[Tuple[float, bytes]]:
    if not _ffmpeg_exists():
        raise RuntimeError("ffmpeg not found.")
    out_pattern = str(Path(out_dir) / "frame_%05d.jpg")
    cmd = [
        get_ffmpeg_path(), "-y",
        "-i", input_path,
        "-vf", f"fps={fps}",
        "-q:v", "2",
        out_pattern
    ]
    _run(cmd)

    frame_files = sorted(Path(out_dir).glob("frame_*.jpg"))
    frames: List[Tuple[float, bytes]] = []
    for idx, fp in enumerate(frame_files):
        t = idx / fps
        frames.append((t, fp.read_bytes()))
    return frames


def _safe_json_from_text(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    m = re.search(r"[\{\[]", text)
    if not m:
        return text
    start = m.start()
    return text[start:]


# -----------------------------
# Gemini tracking with Retry
# -----------------------------
def gemini_track_frames(
    frames: List[Tuple[float, bytes]],
    target_description: str,
    first_click: Optional[Tuple[int, int]] = None,
    image_shape: Optional[Tuple[int, int]] = None,
    model: str = "gemini-3-flash-preview",
    max_retries: int = 2
) -> TrackResponse:
    _require_env()
    # API key is explicitly hardcoded for the demo
    client = genai.Client(api_key="AIzaSyAINZ6sPdzAuaBKK0B-9MgnhPHohmebl6I")

    contents: List[Any] = []
    for (t, img_bytes) in frames:
        contents.append(f"FRAME t={t:.2f}s")
        contents.append(types.Part.from_bytes(data=img_bytes, mime_type="image/jpeg"))

    system_instruction = (
        "You are a precise vision tracking system. "
        "Return ONLY structured JSON that matches the provided schema. "
        "Bounding boxes must be integers in normalized 0..1000 coordinates."
    )

    prompt = f"""Task:
You will receive sequential video frames. Track exactly ONE person who matches this description:
- TARGET: {target_description}
"""

    if first_click and image_shape:
        # Give context about click
        cx, cy = first_click
        h, w = image_shape
        nx = int(cx / w * 1000)
        ny = int(cy / h * 1000)
        prompt += f"\n- POINT HINT: In the first frame, the user clicked near normalized coordinate (x: {nx}, y: {ny}) on the 0..1000 scale. Strongly prefer tracking the person located around this area.\n"

    prompt += """
For each frame:
- If the target is visible, return box_2d = [ymin, xmin, ymax, xmax] normalized to 0..1000 (integers).
- If not visible or ambiguous, return box_2d = null.

Important:
- Output must match the schema. No extra keys. No markdown. No commentary.
- Be consistent across time (prefer the same person).
"""

    schema = TrackResponse.model_json_schema()

    for attempt in range(max_retries):
        try:
            resp = client.models.generate_content(
                model=model,
                contents=contents + [prompt],
                config={
                    "system_instruction": system_instruction,
                    "response_mime_type": "application/json",
                    "response_json_schema": schema,
                },
            )

            raw = _safe_json_from_text(resp.text or "")
            return TrackResponse.model_validate_json(raw)
        except Exception as e:
            if attempt == max_retries - 1:
                try:
                    data = json.loads(raw)
                    return TrackResponse.model_validate(data)
                except:
                    raise e
            # Re-prompt on fail
            prompt += f"\n\nERROR on previous attempt: {str(e)}. Please correct your JSON structure."


# -----------------------------
# Kalman Filter
# -----------------------------
class Kalman1D:
    def __init__(self, init_val, process_noise=1e-3, measurement_noise=1e-1):
        self.kf = cv2.KalmanFilter(2, 1)
        self.kf.transitionMatrix = np.array([[1, 1], [0, 1]], np.float32)
        self.kf.measurementMatrix = np.array([[1, 0]], np.float32)
        self.kf.processNoiseCov = np.eye(2, dtype=np.float32) * process_noise
        self.kf.measurementNoiseCov = np.eye(1, dtype=np.float32) * measurement_noise
        self.kf.statePre = np.array([[init_val], [0]], np.float32)
        self.kf.statePost = np.array([[init_val], [0]], np.float32)

    def update(self, measurement):
        self.kf.predict()
        self.kf.correct(np.array([[np.float32(measurement)]]))
        return float(self.kf.statePost[0, 0])


# -----------------------------
# Crop rendering (CPU)
# -----------------------------
@dataclass
class CropConfig:
    out_w: int = 720
    out_h: int = 1280
    margin: float = 1.5
    smooth_alpha: float = 0.75
    use_kalman: bool = False
    ab_compare: bool = False


def _interp_box(frames: List[TrackFrame], t: float) -> Optional[List[int]]:
    if not frames: return None
    
    # Identify exact segment
    if t < frames[0].t: return frames[0].box_2d
    if t > frames[-1].t: return frames[-1].box_2d
    
    for i in range(len(frames) - 1):
        a = frames[i]
        b = frames[i+1]
        if a.t <= t <= b.t:
             # 타겟이 일시적으로 사라진 구간 (null)
             # 보간하지 않고, 바로 `None`을 리턴하여 렌더러가 "놓침(Missing)" 상태로 인지하게 합니다.
             if a.box_2d is None or b.box_2d is None:
                 return None
             
             if b.t == a.t: return a.box_2d
             r = (t - a.t) / (b.t - a.t)
             return [int(round((1 - r) * a.box_2d[j] + r * b.box_2d[j])) for j in range(4)]
    return None


def render_fancam(
    input_path: str,
    track: TrackResponse,
    out_path_noaudio: str,
    cfg: CropConfig,
) -> str:
    cap = cv2.VideoCapture(input_path)
    if not cap.isOpened():
        raise RuntimeError("Cannot open video for rendering.")

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    in_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    in_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    # Support AB Compare (Double width)
    actual_out_w = cfg.out_w * 2 if cfg.ab_compare else cfg.out_w

    writer = cv2.VideoWriter(
        out_path_noaudio,
        cv2.VideoWriter_fourcc(*"mp4v"),
        fps,
        (actual_out_w, cfg.out_h),
    )

    ema_cx, ema_cy, ema_cw, ema_ch = None, None, None, None
    k_cx, k_cy, k_cw, k_ch = None, None, None, None
    
    target_aspect = cfg.out_w / cfg.out_h
    idx = 0
    
    while True:
        ok, frame = cap.read()
        if not ok: break
        t = idx / fps

        box = _interp_box(track.frames, t)

        if box is None:
            # 인물이 프레임에서 벗어났거나 가려져서 Gemini가 null을 반환한 경우 (Missing)
            # 기본 동작: 점진적으로 원본 전체 화면을 잡도록(Center Crop) 목표 좌표를 설정합니다.
            # (EMA나 Kalman 필터를 거쳐 부드럽게 줌아웃 됩니다)
            cx, cy = in_w / 2, in_h / 2
            ch = in_h
            cw = ch * target_aspect
            if cw > in_w:
                cw = in_w
                ch = cw / target_aspect
        else:
            ymin, xmin, ymax, xmax = [max(0, min(1000, v)) for v in box]
            y1, x1 = int(ymin / 1000 * in_h), int(xmin / 1000 * in_w)
            y2, x2 = int(ymax / 1000 * in_h), int(xmax / 1000 * in_w)

            if x2 <= x1 or y2 <= y1:
                cx, cy = in_w / 2, in_h / 2
                ch = in_h; cw = ch * target_aspect
            else:
                bx, by = (x1 + x2) / 2, (y1 + y2) / 2
                bw, bh = (x2 - x1) * cfg.margin, (y2 - y1) * cfg.margin
                ch = max(bh, bw / target_aspect)
                cw = ch * target_aspect
                cx, cy = bx, by

        # Smoothing & Constraints
        if cfg.use_kalman:
            if k_cx is None:
                k_cx = Kalman1D(cx)
                k_cy = Kalman1D(cy)
                k_cw = Kalman1D(cw)
                k_ch = Kalman1D(ch)
            else:
                # Limit zoom speed
                max_zoom = in_w * 0.05
                cw = np.clip(cw, k_cw.kf.statePost[0, 0] - max_zoom, k_cw.kf.statePost[0, 0] + max_zoom)
                ch = np.clip(ch, k_ch.kf.statePost[0, 0] - max_zoom, k_ch.kf.statePost[0, 0] + max_zoom)
                
            cx = k_cx.update(cx)
            cy = k_cy.update(cy)
            cw = k_cw.update(cw)
            ch = k_ch.update(ch)
        else:
            if ema_cx is None:
                ema_cx, ema_cy, ema_cw, ema_ch = cx, cy, cw, ch
            else:
                 # Zoom limit even for EMA
                max_zoom = in_w * 0.05
                cw = np.clip(cw, ema_cw - max_zoom, ema_cw + max_zoom)
                ch = np.clip(ch, ema_ch - max_zoom, ema_ch + max_zoom)

                a = cfg.smooth_alpha
                ema_cx = a * ema_cx + (1 - a) * cx
                ema_cy = a * ema_cy + (1 - a) * cy
                ema_cw = a * ema_cw + (1 - a) * cw
                ema_ch = a * ema_ch + (1 - a) * ch
                cx, cy, cw, ch = ema_cx, ema_cy, ema_cw, ema_ch

        # Validate bounds
        cw = max(32.0, min(float(in_w), float(cw)))
        ch = max(32.0, min(float(in_h), float(ch)))

        left = int(round(cx - cw / 2))
        top = int(round(cy - ch / 2))
        left = max(0, min(in_w - int(round(cw)), left))
        top = max(0, min(in_h - int(round(ch)), top))
        right, bottom = left + int(round(cw)), top + int(round(ch))

        crop = frame[top:bottom, left:right]
        if crop.size == 0: crop = frame
        fancam_frame = cv2.resize(crop, (cfg.out_w, cfg.out_h), interpolation=cv2.INTER_AREA)

        # Assemble Out Frame
        if cfg.ab_compare:
            # Draw box on original frame for clarity
            orig_annotated = frame.copy()
            if box is not None:
                cv2.rectangle(orig_annotated, (left, top), (right, bottom), (0, 0, 255), 3)
            # Create letterbox/padded square or just resize
            orig_resized = cv2.resize(orig_annotated, (cfg.out_w, cfg.out_h), interpolation=cv2.INTER_AREA)
            final_frame = np.hstack((orig_resized, fancam_frame))
        else:
            final_frame = fancam_frame

        writer.write(final_frame)
        idx += 1

    cap.release()
    writer.release()
    return out_path_noaudio


def mux_audio(original_with_audio: str, video_noaudio: str, out_path: str) -> str:
    if not _ffmpeg_exists():
        shutil.copy(video_noaudio, out_path)
        return out_path

    cmd = [
        get_ffmpeg_path(), "-y",
        "-i", video_noaudio,
        "-i", original_with_audio,
        "-map", "0:v:0",
        "-map", "1:a:0?",
        "-c:v", "libx264",      # 브라우저 재생을 위한 H.264 인코딩
        "-preset", "veryfast",  # 빠른 렌더링
        "-pix_fmt", "yuv420p",  # 필수: Chrome/Safari 등에서 색상 깨짐 및 블랙 스크린 방지
        "-c:a", "aac",
        "-shortest",
        out_path
    ]
    _run(cmd)
    return out_path


def apply_cut_editing(full_video: str, track: TrackResponse, out_path: str):
    """Uses MoviePy to concatenate valid tracking segments."""
    if not HAS_MOVIEPY:
         shutil.copy(full_video, out_path)
         return out_path

    clip = VideoFileClip(full_video)
    fps = clip.fps
    valid_mask = []
    frames_count = int(clip.duration * fps)

    for i in range(frames_count):
        t = i / fps
        box = _interp_box(track.frames, t)
        valid_mask.append(box is not None)

    segments = []
    start = None
    for i, v in enumerate(valid_mask):
        if v and start is None:
            start = i
        elif not v and start is not None:
            # Drop very short segments
            if (i - start) > 5:
                segments.append((start/fps, i/fps))
            start = None
    if start is not None and (len(valid_mask) - start) > 5:
        segments.append((start/fps, clip.duration))

    if not segments:
        # Revert to full video if target never found properly
        shutil.copy(full_video, out_path)
        return out_path

    subclips = [clip.subclip(s, e) for s, e in segments]
    final_clip = concatenate_videoclips(subclips)
    final_clip.write_videofile(out_path, logger=None, audio_codec="aac")
    clip.close()
    return out_path

# -----------------------------
# Main pipeline
# -----------------------------
def make_fancam(
    video_path: str,
    target_description: str,
    click_coords: Optional[Tuple[int, int]] = None,
    image_shape: Optional[Tuple[int, int]] = None,
    start_s: float = 0.0,
    end_s: float = 15.0,
    sample_fps: float = 1.0,
    out_ratio: str = "9:16",
    margin: float = 1.5,
    smooth_alpha: float = 0.75,
    use_kalman: bool = False,
    ab_compare: bool = False,
    auto_cut: bool = False,
    model: str = "gemini-3-flash-preview",
) -> Tuple[str, dict]:

    if out_ratio == "9:16": out_w, out_h = 720, 1280
    elif out_ratio == "16:9": out_w, out_h = 1280, 720
    elif out_ratio == "1:1": out_w, out_h = 1080, 1080

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        clip_path = str(td / "clip.mp4")
        frames_dir = str(td / "frames")
        Path(frames_dir).mkdir(parents=True, exist_ok=True)

        clip_video(video_path, start_s, end_s, clip_path)
        frames = extract_frames(clip_path, fps=sample_fps, out_dir=frames_dir)

        track = gemini_track_frames(
            frames, 
            target_description=target_description,
            first_click=click_coords,
            image_shape=image_shape,
            model=model
        )

        noaudio_path = str(td / "out_noaudio.mp4")
        final_path = str(td / "out_final.mp4")
        cut_path = str(td / "out_cut.mp4")

        cfg = CropConfig(
            out_w=out_w, out_h=out_h, margin=margin, 
            smooth_alpha=smooth_alpha, use_kalman=use_kalman, ab_compare=ab_compare
        )
        render_fancam(clip_path, track, noaudio_path, cfg)
        mux_audio(clip_path, noaudio_path, final_path)

        # Apply Cut Editing
        if auto_cut and HAS_MOVIEPY:
            apply_cut_editing(final_path, track, cut_path)
            export_path = cut_path
        else:
            export_path = final_path

        out_store = Path("outputs")
        out_store.mkdir(exist_ok=True)
        out_file = out_store / f"fancam_{next(tempfile._get_candidate_names())}.mp4"
        shutil.copy(export_path, out_file)

    return str(out_file), track.model_dump()


# -----------------------------
# FastAPI + Gradio
# -----------------------------
app = FastAPI()

def gradio_ui():
    with gr.Blocks(theme=gr.themes.Soft()) as demo:
        gr.Markdown("# 🎥 MVP) Gemini-native Vibe 직캠 메이커\n"
                    "지정된 인물을 Gemini가 찾아서 추적하고 크롭 렌더링합니다.")

        with gr.Row():
            with gr.Column():
                with gr.Tabs():
                    with gr.TabItem("파일 업로드"):
                        video_in = gr.File(label="원본 영상", file_types=["video"])
                    with gr.TabItem("YouTube 주소"):
                        yt_url = gr.Textbox(label="유튜브 URL 주소", placeholder="https://www.youtube.com/watch?v=...")
                        yt_res = gr.Dropdown(["1080p", "720p", "best"], value="720p", label="화질 선택")
                        yt_btn = gr.Button("영상 가져오기 (다운로드)")
                
                start_s = gr.Number(label="시작(초)", value=0)
                end_s = gr.Number(label="끝(초)", value=15)

                def handle_yt_download(url, res):
                    if not url: return None
                    try:
                        out_dir = str(Path("outputs").absolute())
                        Path(out_dir).mkdir(exist_ok=True)
                        out_path = download_youtube_video(url, res, out_dir)
                        return out_path
                    except Exception as e:
                        raise gr.Error(f"YouTube 다운로드 실패: {str(e)}")

                yt_btn.click(handle_yt_download, inputs=[yt_url, yt_res], outputs=[video_in])
                
                # Interactive Frame Click
                orig_first_frame = gr.State(None)
                first_frame_view = gr.Image(label="시작 프레임 (타겟을 직접 클릭하여 점을 찍으세요!)", interactive=False)
                click_state = gr.State(None)
                shape_state = gr.State(None)

                def extract_first(vp, s):
                    if not vp: return None, None
                    cap = cv2.VideoCapture(vp)
                    cap.set(cv2.CAP_PROP_POS_MSEC, s * 1000)
                    ret, fr = cap.read()
                    cap.release()
                    if ret:
                         rgb = cv2.cvtColor(fr, cv2.COLOR_BGR2RGB)
                         return rgb, rgb
                    return None, None

                video_in.change(extract_first, inputs=[video_in, start_s], outputs=[first_frame_view, orig_first_frame])
                start_s.change(extract_first, inputs=[video_in, start_s], outputs=[first_frame_view, orig_first_frame])

                def on_click(evt: gr.SelectData, orig_img):
                    if orig_img is None: 
                        return None, None, None
                    x, y = evt.index
                    marked_img = orig_img.copy()
                    
                    # 사용자 클릭 지점에 십자선과 원(사각/클릭 마커)을 그려 시각적 피드백 제공
                    cv2.circle(marked_img, (x, y), radius=6, color=(255, 0, 0), thickness=-1)
                    cv2.circle(marked_img, (x, y), radius=8, color=(255, 255, 255), thickness=2)
                    cv2.line(marked_img, (x - 20, y), (x + 20, y), (0, 255, 0), 2)
                    cv2.line(marked_img, (x, y - 20), (x, y + 20), (0, 255, 0), 2)
                    
                    return marked_img, evt.index, (orig_img.shape[0], orig_img.shape[1])

                first_frame_view.select(on_click, inputs=[orig_first_frame], outputs=[first_frame_view, click_state, shape_state])

                target = gr.Textbox(label="타겟 추가 설명", placeholder="예: 파란색 바지")
                
                with gr.Accordion("고급 카메라 설정", open=False):
                    sample_fps = gr.Slider(0.5, 5.0, value=1.0, label="Gemini 샘플 FPS")
                    out_ratio = gr.Dropdown(["9:16", "16:9", "1:1"], value="9:16", label="출력 비율")
                    margin = gr.Slider(1.0, 2.5, value=1.5, label="크롭 여백(margin)")
                    smooth_alpha = gr.Slider(0.0, 0.95, value=0.75, label="EMA 스무딩")
                    use_kalman = gr.Checkbox(label="Kalman Filter + 줌 제한 활성화", value=False)
                    ab_compare = gr.Checkbox(label="AB Compare (원본-크롭 좌우 비교)", value=False)
                    auto_cut = gr.Checkbox(label="컷 편집 (놓친 구간 잘라내기)", value=False)
                
                model = gr.Textbox(visible=False, value="gemini-3-flash-preview")
                btn = gr.Button("🚀 직캠 생성 시작", variant="primary")

            with gr.Column():
                video_out = gr.Video(label="결과 직캠")
                json_out = gr.JSON(label="Gemini 추적 결과(JSON)")
                log_out = gr.Textbox(label="실행 로그 (오류 디버깅용)", lines=5, interactive=False)

        def _run_local(vp, td, s, e, fps, ratio, m, a, uk, ab, ac, md, cs, sh):
            try:
                if not vp:
                    return None, None, "오류: 원본 영상이 주어지지 않았습니다."

                if not td:
                    if cs is None:
                         td = "A main character"
                    else:
                         td = "The person clearly clicked by the user"

                out_path, track_json = make_fancam(
                    video_path=vp,
                    target_description=td,
                    click_coords=cs,
                    image_shape=sh,
                    start_s=float(s),
                    end_s=float(e),
                    sample_fps=float(fps),
                    out_ratio=ratio,
                    margin=float(m),
                    smooth_alpha=float(a),
                    use_kalman=uk,
                    ab_compare=ab,
                    auto_cut=ac,
                    model=md.strip()
                )
                return out_path, track_json, "✅ 성공적으로 완료되었습니다."
            except Exception as e:
                err_msg = traceback.format_exc()
                return None, None, f"❌ 오류가 발생했습니다:\n{err_msg}"

        btn.click(
            _run_local,
            inputs=[video_in, target, start_s, end_s, sample_fps, out_ratio, margin, smooth_alpha, use_kalman, ab_compare, auto_cut, model, click_state, shape_state],
            outputs=[video_out, json_out, log_out],
        )

    return demo

demo = gradio_ui()
app = gr.mount_gradio_app(app, demo, path="/")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=7860)
